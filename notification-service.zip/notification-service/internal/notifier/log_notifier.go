package notifier

import (
	"context"
	"log/slog"

	"notification-service/internal/event"
)

type LogNotifier struct {
	logger *slog.Logger
}

func NewLogNotifier(logger *slog.Logger) *LogNotifier {
	return &LogNotifier{logger: logger}
}

func (n *LogNotifier) Send(ctx context.Context, e event.RewardClaimedEvent) error {
	n.logger.Info("reward claimed notification sent",
		"eventId", e.EventID,
		"userId", e.UserID,
		"walletId", e.WalletID,
		"amount", e.Amount,
	)
	return nil
}